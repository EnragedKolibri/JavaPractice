package com.example.inrt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprInroApplication {

    public static void main(String[] args) {
        SpringApplication.run(SprInroApplication.class, args);
    }
}
